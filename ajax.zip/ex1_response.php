<?php

    $result=$_POST['v'];
    echo $result;
    exit;
?>