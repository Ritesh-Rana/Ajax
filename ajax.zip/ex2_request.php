<!DOCTYPE html>
<html>

<head>
	<title>change</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script>
		$(document).ready(function() {
			$("#btn").click(function() {
				$.ajax({
					url: 'ex2_response.php',
					type: 'GET',
					dataType: 'html',
					success: function(data) {
						$("#unsort").html(data);
					}
				});
			});
		});
	</script>
</head>

<body>
	<div class="unsort" id="unsort" style="font-size: 30px;">

	</div>
	<div class="sort" id="sort" style="font-size: 30px;">

	</div>
	<h1>Click below to get unsorted and then sorted array</h1>
	<button id="btn" style="width: 50%;">click me  </button>

	
</body>

</html>