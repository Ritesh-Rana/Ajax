<?php
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL); 

$conn =new mysqli("localhost","admin","admin","jquery");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }


  $sql='SELECT * FROM record';

  $table=mysqli_query($conn,$sql);

 
echo "  <div class='table' id='table'>
        <table>
        <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Roll No.</th>
        <th>Class</th>
        <th>Subject</th>
        </tr>
        ";
while($row = $table->fetch_assoc()) {
        echo "<tr>";
        echo "<td>";
        echo $row['id'];
        echo "</td>";
        echo "<td>";
        echo $row['name'];
        echo "</td>";
        echo "<td>";
        echo $row['rollnumber'];
        echo "</td>";
        echo "<td>";
        echo $row['class'];
        echo "</td>";
        echo "<td>";
        echo $row['subject'];
        echo "</td>";
        echo "</tr>";
        }
        echo "</table>
                </div>";
?>