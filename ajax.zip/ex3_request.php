<!DOCTYPE html>
<html>

<head>
	<title>change</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script>
		$(document).ready(function() {
			$("#btn").click(function() {
				$.ajax({
					url: 'ex3_response.php',
					type: 'GET',
					dataType: 'html',
					success: function(data) {
						$("#table").html(data);
					}
				});
			});
		});
	</script>
</head>

<body>
    <h1>Click below to get table</h1>
    <button id="btn">Get Table</button>
    <div class="table" id="table">

    </div>
	
</body>

</html>