<?php
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL); 

$array = array("Hello", "how", "what", "why", "where", "answer", "quetion", "ritesh", "shivam", "rohan");

echo "Unsorted Array:\n";
$unsort="";
$unsort.="<div class='unsort'>";
for($i=0;$i<10;$i++){
    $unsort.=$array[$i]." ";
}
$unsort.="</div>";
echo $unsort;

echo "Sorted Array:\n";

sort($array);

$sort="";
$sort.="<div class='sort'>";
for($i=0;$i<10;$i++){
    $sort.=$array[$i]." ";
}
$sort.="</div>";
echo $sort;
?>