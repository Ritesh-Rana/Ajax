<!DOCTYPE html>
<html>

<head>
	<title>change</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>

<body>
	<p id="change">Hi all what are you doing .....!</p>
	<input type="text" name="text" id="fo">
	<button id="btn">click</button>

	<script>
		$(document).ready(function () {
			$("#btn").click(function () {
				var value="v="+$("#fo").val();
				$.ajax({
					url:'ex1_response.php',
					type:'POST',
					data:value,
					success: function(data){
						$('#change').html(data);
					}
				});
			});
		});
	</script>
</body>

</html>